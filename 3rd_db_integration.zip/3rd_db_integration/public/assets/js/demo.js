
// $(document).ready(function(){
//   $('#Add-form').hide();
// });


 $('#Add').click(function(){
    $('#address-form').toggle();
    $('#Add').hide();
  });

 $('#cancel').click(function(){
    $('#address-form').hide();
    $('#Add').show();
  });



$("#PC").on("submit", function () {
  var pc_val = $('#PostalCode').val();
  if (pc_val.length == '') {
    $('#pcCheck').html("please enter PostalCode");
    $('#pcCheck').css("color", "red");
    $('#pcCheck').fadeOut("slow");
  }
  let PostalCode = $('#PostalCode').val();
  let data = { 
    check: true,
    PostalCode: PostalCode 
  }
  let form = $(this);
  // alert(form);

  $.ajax({
    type: 'post',
    url: 'http://localhost/Home_DB/functions/checkAvailability',
    data: form.serialize(),
    dataType: 'json',
    success: function (data) {
      console.log(data.Message);
      
      if (data.status == "Success") {
        $('a[href="#menu1"]').tab("show");
        $('#Pc').val(data.pc);
        localStorage.setItem("PostalCode", JSON.stringify(data));
      } else {
        alert(data.Message);
      }
    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
      alert("something went wrong.")
      console.log(XMLHttpRequest, textStatus, errorThrown);
    }

  });

  return false;

});

$(document).ready(function () {


  
  $('#date').change(function () {
    var a = $(this).val();
    $('#Date').html(a);

  });

  $('#time').change(function () {
    var b = $(this).val()
    $('#Time').html("@ " + b + " pm");
  });

  $('#hrs').change(function () {
    var c = $(this).val()
    $('#Hr').html(c);
  });

  $("#img1").click(function(){
    if ($(this).attr("src") == "http://localhost/Home_DB/public/assets/images/book-service/1.png") {
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/1-green.png");
    }
    else{
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/1.png");
    }
    
  });

  $("#img2").click(function(){
    if ($(this).attr("src") == "http://localhost/Home_DB/public/assets/images/book-service/2.png") {
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/2-green.png");
    }
    else{
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/2.png");
    }
    
  });

  $("#img3").click(function(){
    if ($(this).attr("src") == "http://localhost/Home_DB/public/assets/images/book-service/3.png") {
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/3-green.png");
    }
    else{
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/3.png");
    }
    
  });

  $("#img4").click(function(){
    if ($(this).attr("src") == "http://localhost/Home_DB/public/assets/images/book-service/4.png") {
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/4-green.png");
    }
    else{
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/4.png");
    }
    
  });

  $("#img5").click(function(){
    if ($(this).attr("src") == "http://localhost/Home_DB/public/assets/images/book-service/5.png") {
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/5-green.png");
    }
    else{
      $(this).attr("src", "http://localhost/Home_DB/public/assets/images/book-service/5.png");
    }
    
  });



  $(".cb-services").click(function() {
    let text = $(this).val();
    let id = "extra-" + $(this).attr("id");
    let isChecked = $(this).is(':checked');

    if(isChecked) {
      let details = "<div id=" + id + ">";
      details += "<span>" + text + "</span>"
      details += '<span class="float-end"> 30 min </span>'
      details += "</div>";
  
      $(details).appendTo($("#extra-services"));
    }
    else {
      $("#" + id).remove();
    }
  });


   $('.cb-services').click(function() {
                    var checkboxes = $('input:checkbox:checked').length;
                    // alert(checkboxes);
                    if (checkboxes == 1) {
                      $('#thr').text("3.5 Hrs");
                    }
                    else if(checkboxes == 2){
                      $('#thr').text("4 Hrs");
                    }
                     else if(checkboxes == 3){
                      $('#thr').text("4.5 Hrs");
                    }
                     else if(checkboxes == 4){
                      $('#thr').text("5 Hrs");
                    }
                    else if(checkboxes == 5){
                      $('#thr').text("5.5 Hrs");
                    }
                });

   $('input[type="radio"]').click(function(){
    var helo = $(this).val();
    // $('#h1').html(helo);

    $.ajax({
      type: 'post',
      url: 'http://localhost/Home_DB/functions/radio',
      data:{
        check: true,
        helo: helo,
      },
      dataType: 'json',
    // alert("hello");
    cache: false,
    success: function(data){
      console.log(data.Message);
      if(data.status == "Success"){
                    alert('success');
                    // $('a[href="#menu2"]').tab("show");
                    // localStorage.setItem("data", JSON.stringify(data));
                }else{
                    // alert('failer');
                    alert(data.Message);
                }
    },
     error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("Status: " + textStatus); alert("Error: " + errorThrown); 
    }   
    });

    return false;
  
  });

});



$("#schedule").on("submit", function(){
   //Code: Action (like ajax...)
   var date_val = $('#date').val();
  if (date_val.length == '') {
    $('#dateCheck').html("please enter date");
    $('#dateCheck').css("color", "red");
    $('#dateCheck').fadeOut("slow");
  }
   var date = $('#date').val();
   var time = $('#time').val();
   var hrs = $('#hrs').val();
   // var extras = $('.cb-services').val();
   var cmt = $('#cmt').val();
    var insert = [];
                $('.cb-services').each(function() {
                    if ($(this).is(":checked")) {
                        insert.push($(this).val());
                    }
                });
                insert = insert.toString();
  // alert(extras);
  // alert(insert);


  $.ajax({
    type: 'post',
    url: 'http://localhost/Home_DB/functions/schedule',
    // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    data: {
      check: true,
      date: date,
      time: time,
      hrs: hrs,
      // extras: extras,
      insert: insert,
      cmt: cmt,

    },
    dataType: 'json',
    // alert("hello");
    cache: false,
    success: function(data){
      console.log(data.Message);
      if(data.status == "Success"){
                    // alert('success');
                    $('a[href="#menu2"]').tab("show");
                    localStorage.setItem("data", JSON.stringify(data));
                }else{
                    // alert('failer');
                    console.log(data.Message);
                }
    },
     error: function(XMLHttpRequest, textStatus, errorThrown) { 
        console.log("Status: " + textStatus); console.log("Error: " + errorThrown); 
    }   
   
   
 });

  return false;

});


$("#Add-form").on("submit", function(){
   //Code: Action (like ajax...)
   var street = $('#street').val();
   var HN = $('#HN').val();
   var Pc = $('#Pc').val();
   var mobile = $('#mobile').val();
   var city = $('#city').val();
   var Userid = $('#Userid').val();
   
  $.ajax({
    type: 'post',
    url: 'http://localhost/Home_DB/functions/address',
    data: {
      check: true,
      street: street,
      HN: HN,
      Pc: Pc,
      Userid: Userid,
      mobile: mobile,
      city: city,

    },
    dataType: 'json',
    // alert("a");
    cache: false,
    success: function(data){
      console.log(data.Message);
      if(data.status == "Success"){
                    // alert('success');
                    console.log('success');
                    $('#add2').show();
                    // $('#address1').html('Address');
                    // $('#colon').html(':');
                    // $('#colon').html(':');
                    // $('phone1').html('Phone number');
                    var s_val = $('#street').val();
                     $('#Street').html(s_val);
                     var h_val = $('#HN').val();
                     $('#Hn').html(h_val);
                     var p_val = $('#Pc').val();
                     $('#pc1').html(p_val);
                     var c_val = $('#city').val();
                     $('#City').html(c_val);
                     var m_val = $('#mobile').val();
                     $('#Mobile').html(m_val);
                     $('#address-form').hide();
                      $('#Add').show();
                    // $('a[href="#menu3"]').tab("show");
                }else{
                    // alert('failer');
                    alert(data.Message);
                }
    },
     error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("Status: " + textStatus); alert("Error: " + errorThrown); 
    }   
   
   
 });

  return false;

});


// $("#ok").on("submit", function(){
//   $('a[href="#menu3"]').tab("show");
// })
$('#ok').click(function(){
  $('a[href="#menu3"]').tab("show");
})