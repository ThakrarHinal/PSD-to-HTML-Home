AOS.init({

	 offset: 10,
	 easing: 'ease',
	 duration: 1000,
	 // startEvent: 'DOMContentLoaded', 
});

$(window).scroll(function(){
	$('nav').toggleClass('scrolled',$(this).scrollTop()>50);
});

$('#finalizeSchedules1').click(function(){
	$('#modalcontainer').css('opacity', '0');

});

$('#login').click(function(){
	// $('#modalcontainer1').css('opacity', '0') &&
	$('#modalcontainer').css('opacity', '1');
})

