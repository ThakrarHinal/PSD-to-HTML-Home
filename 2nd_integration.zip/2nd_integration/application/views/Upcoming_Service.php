

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="http://localhost/Home_DB/assets/css/Upcoming_Serive.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto&family=Work+Sans&display=swap" rel="stylesheet">

    <title>Service Provider -> Upcoming Service</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light Rectangle sticky-top ">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"><img class="img" src="http://localhost/Home_DB/public/assets/images/UpcomingServices/logo-small.png" alt=""></a>
          <button class="navbar-toggler" onclick="responsive_menu()" id="iconbar" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="#">Prices & services</a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="#">Warranty</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Blog</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Contact</a>
              </li>
              <li class="nav-item">
                  <div class="vl"></div>
              </li>
              <li class="nav-item">
                <button type="button" class="btn position-relative nav-link">
                        <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/notification.png" alt="">
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                      2
                      <span class="visually-hidden">unread messages</span>
                    </span>
                  </button>
              </li>
             
              <li class="nav-item">
                <div class="vl"></div>
            </li>
              
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/Contact.png" alt="">
                </a>         
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="#">Action</a></li>
                  <li><a class="dropdown-item" href="#">Another action</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="#">Something else here</a></li>
                </ul>
              </li>
            </ul>
           
            

            
          </div>
        </div>
      </nav>

      <div class="wlc box">
          <h2 class="text-center wlc-wrd">Welcome, <b><?php echo $this->getSession('First_name');?></b> </h2>
      </div>


        
      

        
          <div class="ver-nav navbar-collapse navbar navbar-nav">
              <ul class="list1" id="menu_small">
                <li class="nav-item"><a class="item nav-tabs" href="#home">Dashboard</a></li>
                <li class="nav-item"><a class="item nav-tabs" href="#news">New Service Requests</a></li>
                <li class="nav-item"><a class="item active nav-tabs" href="#contact">Upcoming Services</a></li>
                <li class="nav-item"><a class="item nav-tabs" href="#about">Service Schedule</a></li>
                <li class="nav-item"><a class="item nav-tabs" href="#about">Service History</a></li>
                <li class="nav-item"><a class="item nav-tabs" href="#about">My Ratings</a></li>
                <li class="nav-item"><a class="item nav-tabs" href="#about">Block Customer</a></li>
              </ul>
          </div>
          
    
  
          <table class="table tb table-responsive justify-content-center">
            <thead class="table-light">
              <tr>
                <td>Service ID <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/data.png" alt=""> </td>
                <td>Service date  <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/data.png" alt=""> </td>
                <td>Customer details  <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/data.png" alt="">  </td>
                <td>Distance <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/data.png" alt=""> </td>
                <td>Actions</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>323436</td>
                <td> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt=""> 09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>15 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323437</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>10 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323438</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>15 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323439</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>15 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323440</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>10 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323441</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>25 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323442</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>15 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323443</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>05 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323444</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>15 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
              <tr>
                <td>323445</td>
                <td><img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/cal.png" alt="">09/04/2018</div>
                <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/time.png" alt=""> 12:00 - 18:00</div></td>
                <td>
                  <div>David Bough</div>
                  <div> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/home.png" alt=""> Musterstrabe 5,12345 Bonn</div>
                </td>
                <td>05 km</td>
                <td><button class="btn btn1 border">Cancel</button></td>
              </tr>
            </tbody>
           
           
    
          </table>
  
        </div>

        
        <section class="f1">
          <div class=" my-5">

            <footer class=" text-center text-white" style="background-color: #111111;">
            <!-- Grid container -->
            <div class="container p-3 pb-0">
              <!-- Section: Social media -->
              <section class="mb-4">
                <span class="foot"> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/footer.png" alt=""></span>
                <span class="foot1">HOME</span>
                <span class="foot1">ABOUT</span>
                <span class="foot1">TESTIMONIALS</span>
                <span class="foot1">FAQS</span>
                <span class="foot1">INSURANCE POLICY</span>
                <span class="foot1">IMPRESSUM</span>
                <span class="fb"> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/FB.png" alt=""></span>
                <span> <img src="http://localhost/Home_DB/public/assets/images/UpcomingServices/insta (1).png" alt=""></span>
                
                
          
              
              </section>
              <!-- Section: Social media -->
            </div>
  
            <hr class="hr1">
            <!-- Grid container -->
          
            <!-- Copyright -->
            <div class="text-center p-3 l-txt" style="background-color: #111111;">
              ©2018 Helperland. 
              <a class="text-white l-txt">All rights reserved. Terms and Conditions | Privacy Policy</a>
            </div>
            <!-- Copyright -->
          </footer>
            
          </div>
  
        </section>

      


     
           
      <script src="http://localhost/Home_DB/assets/js/Upcomingservice.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    
  </body>
</html>