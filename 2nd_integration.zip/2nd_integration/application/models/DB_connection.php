<?php

class DB_connection extends database{

    function contact($name, $mobile_number, $Email, $Subject, $Message, $file){


            if($this->Query("INSERT INTO ContactUs(Name, Mobile_number, Email, Subject, Message, file, time) VALUES ('$name', '$mobile_number', '$Email', '$Subject', '$Message', '$file', CURTIME())")){
            return true;
            
        }
        else{
     
            return false;
            
        }

        
        }

        function insertUser($data){

            if($this->Query("INSERT INTO User(First_name, Last_name, Mobile, Email, Password, token, status, typeId) VALUES 
                (?,?,?,?,?,?,?,?)", $data)){

                return true;
            }
            else{
                return false;
            }
        }

        function checkEmail($email){
            if ($this->Query("SELECT Email FROM User WHERE email = ?", [$email])) {
                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    return false;
                    
                }
                else{
                    return true;
                    
                }
            }
        }




        function userLogin($email, $password){
            if ($this->Query("SELECT * FROM User WHERE email = ?", [$email])) {
                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    $row = $this->fetch();
                    $dbPassword = $row->Password;
                    $userId = $row->Userid;
                    $First_name = $row->First_name;
                    $dbemail = $row->email;
                    $typeId = $row->typeId;
                    if (password_verify($password, $dbPassword)) {
                        // code...
                        return ['status' => 'ok', 'data' => $userId, 'name' => $First_name, 'typeId' => $typeId];
                    }
                    else{
                        return ['status' => 'passwordNotMatch'];
                    }
                }
                else{
                    return ['status' => 'emailNotFound'];
                }
            }
        }


        function Reset($new_pass ,$Email){
            if ($this->Query("UPDATE User SET Password=$new_pass WHERE email = ?", [$Email])) {
                // code...
                return true;
            }
            else{
                return false;
            }
        }






        function check_Email($Email){
            if ($this->Query("SELECT Email,First_name,token FROM User WHERE email = ?", [$Email])) {
                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    $row = $this->fetch();
                    $First_name = $row->First_name;
                    $token = $row->token;
                    return [ 'First_name' => $First_name, 'token' => $token];
                    return true;
                    // 
                    
                }
                else{
                    return false;
                    
                }
            }
        }





    }



?>

