<?php include('header.php');    ?>

<title>About</title>
<link rel="stylesheet" href="http://localhost/Home_DB/assets/css/About.css">

        <div><img class="img-1 img-fluid" src="http://localhost/Home_DB/assets/images/About/Bg-img.jpg" alt=""></div>

        <h2 class="text-center ab-us"><b> A Few words about us</b></h2>
            
        <div class="d-flex">
          <hr class="line">
          <img class="star" src="http://localhost/Home_DB/assets/images/About/star.png" alt="">
          <hr class="line-1">
        </div><br><br>

        <p class="pr1 text-center">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean molestie convallis tempor. Duis vestibulum vel risus condimentum dictum. <br> Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus quis enim orci. Fusce risus lacus, <br> sollicitudin eu magna sed, pharetra sodales libero. Proin tincidunt vel erat id porttitor. Donec tristique est arcu, sed dignissim velit vulputate <br> ultricies.
        </p>
          <p class="pr1 text-center">
          Interdum et malesuada fames ac ante ipsum primis in faucibus. In hac habitasse platea dictumst. Vivamus eget mauris eget nisl euismod <br> volutpat sed sed libero. Quisque sit amet lectus ex. Ut semper ligula et mauris tincidunt hendrerit. Aenean ut rhoncus orci, vel elementum <br> turpis. Donec tempor aliquet magna eu fringilla. Nam lobortis libero ut odio finibus lobortis. In hac habitasse platea dictumst. Mauris a <br> hendrerit felis. Praesent ac vehicula ipsum, at porta tellus. Sed dolor augue, posuere sed neque eget, aliquam ultricies velit. Sed lacus elit, <br> tincidunt et massa ac, vehicula placerat lorem. 
          </p>

        <h2 class="text-center o-stry"><b>Our Story</b> </h2>
            
        <div class="d-flex">
          <hr class="line">
          <img class="star" src="http://localhost/Home_DB/assets/images/About/star.png" alt="">
          <hr class="line-1">
        </div><br><br>

        <p class="text-center pr1">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean molestie convallis tempor. Duis vestibulum vel risus condimentum dictum. <br> Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus quis enim orci. Fusce risus lacus, <br> sollicitudin eu magna sed, pharetra sodales libero. Proin tincidunt vel erat id porttitor. Donec tristique est arcu, sed dignissim velit vulputate <br> ultricies.
          </p>
          <p class="text-center pr1">
          Interdum et malesuada fames ac ante ipsum primis in faucibus. In hac habitasse platea dictumst. Vivamus eget mauris eget nisl euismod <br> volutpat sed sed libero. Quisque sit amet lectus ex. Ut semper ligula et mauris tincidunt hendrerit. 
          </p>
          <p class="text-center pr1">
          
          Aenean ut rhoncus orci, vel elementum turpis. Donec tempor aliquet magna eu fringilla. Nam lobortis libero ut odio finibus lobortis. In hac <br> habitasse platea dictumst. Mauris a hendrerit felis. Praesent ac vehicula ipsum, at porta tellus. Sed dolor augue, posuere sed neque eget, <br> aliquam ultricies velit. Sed lacus elit, tincidunt et massa ac, vehicula placerat lorem. 
        </p>


        <h2 class="text-center news" ><b> GET OUR NEWSLETTER</b>
        
        </h2><br>

          
        <form class="row g-2 container-fluid justify-content-center">
          
          <div class="col-auto ">
            <input type="text" class="form-control email" id="inputEmail" placeholder="YOUR EMAIL">
          </div>
          <div class="col-auto">
            <button type="submit" class="btn Submit  mb-3">Submit</button>
          </div>
          
        </div>
        
        </form>

        <div class=" my-5">

          <footer class=" text-center text-white" style="background-color: #111111;">
          <!-- Grid container -->
          <div class="container p-3 pb-0">
            <!-- Section: Social media -->
            <section class="mb-4">
             <a href="<?php echo BASEURL; ?>/functions/Home"><span class="foot"> <img src="http://localhost/Home_DB/assets/images/About/footer.png" alt=""></span></a> 
              <a href="<?php echo BASEURL; ?>/functions/Home" class="foot-link"><span class="foot1">HOME</span></a>
              <a href="<?php echo BASEURL; ?>/functions/About" class="foot-link"><span class="foot1">ABOUT</span></a>
              <a href="#" class="foot-link"><span class="foot1" >TESTIMONIALS</span></a>
              <a href="<?php echo BASEURL; ?>/functions/FAQ" class="foot-link"><span class="foot1">FAQS</span></a>
              <a href="#" class="foot-link"><span class="foot1">INSURANCE POLICY</span></a>
              <a href="#" class="foot-link"><span class="foot1">IMPRESSUM</span></a>  
              <span class="fb"> <img src="http://localhost/Home_DB/assets/images/About/FB.png" alt=""></span>
              <span> <img src="http://localhost/Home_DB/assets/images/About/insta (1).png" alt=""></span>
              
              
        
            
            </section>
            <!-- Section: Social media -->
          </div>

          <hr class="hr1">
          <!-- Grid container -->
        
          <!-- Copyright -->
          <div class="text-center p-3 l-txt" style="background-color: #111111;">
            © 2020 Copyright:
            <a class="text-white l-txt">All rights reserved. Terms and Conditions | Privacy Policy</a>
          </div>
          <!-- Copyright -->
        </footer>
          
        </div>

      
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    
    </body>
  </html>