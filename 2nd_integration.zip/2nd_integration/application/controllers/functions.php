<?php
class functions extends framework
{
     public function Home(){

           
            $this->view('Home');
    }

    public function Prices(){

               $this->view('Prices');
    }

    public function Contact(){

               $this->view('Contact');
    }

    public function FAQ(){

               $this->view('FAQ');
    }

    public function About(){

               $this->view('About');
    }

    public function signin(){

               $this->view('signin');
    }

    public function login(){

               $this->view('login');
    }

    public function Service_History(){

               $this->view('Service_History');
    }

    public function reset(){

               $this->view('reset');
    }

    public function Service_provider(){

               $this->view('Service_provider');
    }

    public function Upcoming_Service(){

               $this->view('Upcoming_Service');
    }


    public function insert(){
        $this->view("Contact");
         
        if (isset($_POST['submit'])) {
            // code...

              $First_name = $this->input('First_name');
               $Last_name = $this->input('Last_name');
               $Mobile_number = $this->input('Mobile_number');
               $Email = $this->input('Email');
               $Subject = $this->input('Subject');
               $Message = $this->input('Message');
               $file = $this->input('file');
               $options = $this->input('options');

               $name = $First_name.$Last_name;
               $mobile_number = $options.$Mobile_number;

             $myModel = $this->model('DB_connection');
             if($myModel->contact($name, $mobile_number, $Email, $Subject, $Message, $file)){
                echo "added";
             }else{
                echo "not added";
             }
            
             require 'PHPMailerAutoload.php';
             require 'credentials.php';

            $mail = new PHPMailer;

            // $mail->SMTPDebug = 4;                               // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'hinalthakrar22@gmail.com';                 // SMTP username
            $mail->Password = 'ocdorpyqhctrnykd';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to 

            $mail->setFrom(EMAIL, 'Mailer');
            $mail->addAddress(EMAIL);     // Add a recipient
           
            $mail->addReplyTo(EMAIL);
            
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = 'Here is the subject';
            $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            if(!$mail->send()) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {
            echo 'Message has been sent';
            }

                }
                
                 

            }



            public function UserInsert(){
                $this->view('signin');

                if (isset($_POST['register'])) {
                    // code...

                    $userData = [
                    'First_name' => $this->input('First_name'),
                    'Last_name'  => $this->input('Last_name'),
                    'mobile'     => $this->input('mobile'),
                    'email'      => $this->input('email'),
                    'pass'       => $this->input('pass'),
                    'Repeat_password' => $this->input('Repeat_password'),
                    'emailError' => '',
                    'token'      => '',
                    'status'     => '',
                    'tupeId'     => '',
                  ];


                            $typeId = 1;
                            $status = "inactive";
                            $token = bin2hex(random_bytes(15));
                             $password = password_hash($userData['pass'], PASSWORD_DEFAULT) ;  

                  

                    $myModel = $this->model('DB_connection');
                        if($myModel->checkEmail($userData['email'])){
                            
                            if($userData['pass'] === $userData['Repeat_password']) {
                                // code...
                                $data = [$userData['First_name'], $userData['Last_name'], $userData['mobile'], $userData['email'], $password, $token, $status, $typeId];
                                 if($myModel->insertUser($data)){
                                    header("location:" . BASEURL . "/functions/Home");
                             }

                             }else{
                                $this->setFlash("passNotMatch", "password not matched");
                            }

                        }
                        else{

                            $this->setSession("exist", "already exist");
                            
                        }
                }

            }




            public function userlogin(){
                // $this->view('signin');
                setcookie('emailCookie', 'cookie set')? "pass": "fail";
                setcookie('passCookie', 'cookie set')? "pass": "fail";
                echo "hello";
                 if (isset($_POST['login'])) {
                    // code...
                    echo "hey there";
                    $userData = [
                    'email'      => $this->input('email'),
                    'password'   => $this->input('password'),
                    'remember-me' => $this->input('remember-me'),
                    'emailError' => '',
                 ];


                 $myModel = $this->model('DB_connection');
                 $result = $myModel->userLogin($userData['email'], $userData['password'], $userData['remember-me']);
                 if ($result['status'] === 'emailNotFound') {
                     // code...
                    echo "invalid Email";
                 }
                 elseif ($result['status'] === 'passwordNotMatch') {
                     // code...
                    echo "invalid password";
                 }
                 elseif ($result['status'] === 'ok'){
                    $this->setSession('Userid', $result['data']);
                    $this->setSession('First_name', $result['name']);
                    $this->setSession('typeId', $result['typeId']);
                    $Typid = $this->getSession('typeId');
                    if ($Typid == 0) {
                        // code...
                        header("location:" . BASEURL . "/functions/Service_History");
                    }
                    elseif($Typid == 1) {
                        header("location:" . BASEURL . "/functions/Upcoming_Service");
                    }
                    
                 }

            }

}

                public function logout(){
                    $this->destroy();
                    echo "hey";
                    header("location:" . BASEURL . "/functions/Home");
                }


                public function pass(){
                    $this->view('Home');
                    if (isset($_POST['send'])) {
                        // code...
                        $Email = $this->input('Email');
                         $myModel = $this->model('DB_connection');
                        $result = $myModel->check_Email($Email);
                         
                         if($result){

                             // $this->setSession('');
                             $this->setSession('First_name', $result['First_name']);
                             $this->setSession('token', $result['token']);
                            $res = $this->getSession('First_name');
                            $Token = $this->getSession('token');

                                require 'PHPMailerAutoload.php';
                                 require 'credentials.php';

                                $mail = new PHPMailer;

                                $mail->isSMTP();                                      // Set mailer to use SMTP
                                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                                $mail->Username = 'hinalthakrar22@gmail.com';                 // SMTP username
                                $mail->Password = 'ocdorpyqhctrnykd';                           // SMTP password
                                $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
                                $mail->Port = 587;                                    // TCP port to connect to 

                                $mail->setFrom(EMAIL, 'Mailer');
                                $mail->addAddress($Email);     // Add a recipient
                               
                                $mail->addReplyTo($Email);
                                
                                $mail->isHTML(true);                                  // Set email format to HTML

                                $mail->Subject = 'Forget password?';
                                $mail->Body    = 'This is '.$res.'  the HTML message body <b>in bold!</b> Message send! http://localhost/Home_DB/functions/reset?token='.$Token.'';
                                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                                if(!$mail->send()) {
                                    $this->setSession("email_sent", "email sent successfully");
                                   echo $this->getSession('email_sent');
                                } else {
                                     $this->setFlash("email_sent", "email sent successfully");
                                 }

                            }

                                 else{
                                    echo "not exist";
                                 }
                       
                        

                    }
                }
                public function forgetPass(){
                    if (isset($_POST['update'])) {
                        $this->view('reset');
                        $Email = $_POST['email'];
                            // if (isset($Token)) {
                                $new_pass = $this->input('new_pass');
                                $con_pass = $this->input('con_pass');
                                  $myModel = $this->model('DB_connection');
                                  if($myModel->Reset($new_pass, $Email)){
                                    $this->setSession("passUpdate", "password updated");
                                  }
                                  else{
                                    $this->setSession("passUpdateNot", "password not updated there is some error");
                                  }
                            }

                      
                    }
                }

// }

   

?>