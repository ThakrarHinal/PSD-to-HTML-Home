<?php include('header.php');   ?>

        <link rel="stylesheet" href="http://localhost/Home_DB/assets/css/FAQ.css">

        <title>FAQ</title>


          <!-- img -->
          <div class="img-fluid img-1"><img src="http://localhost/Home_DB/assets/images/faq/Bg-img.png" alt=""></div>

          <h2 class="text-center">FAQs</h2>
          
          <div class="d-flex">
            <hr class="line">
            <img class="star" src="http://localhost/Home_DB/assets/images/faq/star.png" alt="">
            <hr class="line-1">
          </div>

          <div class="text-center text-4">Whether you are Customer or Service provider, <br> We have tried our best to solve all your queries and questions.</div>
      
          

          <div class="btn-group d-flex buttons">
            <a href="#" class="btn active customer" aria-current="page">FOR CUSTOMER</a>
            <a href="#" class="btn service">FOR SERVICE PROVIDER</a>
          </div>
          

          
        
        <!-- content -->

          <div>
          <img src="http://localhost/Home_DB/assets/images/faq/btn-2.png" id="for-customer" class="btn-2 btn" alt="">
            <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
          </div><br>
          <div class="text-1 text-sm-start">
            <span >Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id diam tincidunt, fringilla vitae, dapibus velit. Vivamus id <br> tortor rhoncus, efficitur at, suscipit tortor. Integer fermentum convallis eros semper. Ut non imperdiet velit. Praesent <br> eu dui lacus porta eleifend eget quis dui. Integer tempus massa gravida tincidunt. Fusce libero tristique, euismod nisi <br> vel, luctus urna. Interdum malesuada fames ante ipsum primis faucibus. Donec et placerat arcu. Suspendisse lacinia <br> tristique massa. Etiam justo, scelerisque arcu eu, sodales tempor eros. Aliquam efficitur pretium urna, sit amet congue <br> risus malesuada rutrum. Donec id vel velit ullamcorper accumsan ut eget nisl. Fusce viverra commodo lacus, sit amet <br> facilisis leo luctus dictum.</span>
          </div>
          <div><br>
            <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
              <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
            </div><br>
            <div>
              <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
                <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
              </div><br>
              <div>
                <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
                  <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
                </div><br>
                <div>
                  <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
                    <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
                  </div><br>
                  <div>
                    <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
                      <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
                    </div><br>
                    <div>
                      <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
                        <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
                      </div><br>
                      <div class="last-div">
                        <img src="http://localhost/Home_DB/assets/images/faq/btn-1.png" class="btn-2" alt="">
                          <span class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nisl nunc, iaculis mattis tellus imperdiet velit?</span>
                        </div>
      
<!-- /content -->
<link rel="stylesheet" href="http://localhost/Home_DB/assets/css/footer.css">
<div class="text-center news">
                            <b> GET OUR NEWSLETTER</b> 
                        </div>

                        <form class="row g-3 justify-content-center">
                          
                          <div class="col-auto justify-content-center">
                            <label for="inputEmail" class="visually-hidden">YOUR EMAIL</label>
                            <input type="text" class="form-control email" id="inputEmail" placeholder="YOUR EMAIL">
                          </div>
                          <div class="col-auto">
                            <button type="submit" class="btn Submit  mb-3">Submit</button>
                          </div>
                        
                        </div>
                        </form>

                        

        
<!-- footer --> 
                          <footer class="text-center text-sm-start " style="background-color: black;">
                              <p class="menu justify-content-center list-1 py-3">
                                <a href="<?php echo BASEURL; ?>/functions/Home"><img class="footer-img" src="http://localhost/Home_DB/assets/images/faq/footer.png" alt=""></a>
                                <a class="col-sm-8 color-me-1 text-2 text-3" href="<?php echo BASEURL; ?>/functions/Home">HOME</a>
                                <a class="col-sm-8 color-me-1 text-3" href="<?php echo BASEURL; ?>/functions/About">ABOUT</a>
                                <a class="col-sm-8 color-me-1 text-3" href="">TESTIMONIALS</a>
                                <a class="col-sm-8 color-me-1 text-3" href="<?php echo BASEURL; ?>/functions/FAQ">FAQS</a>
                                <a class="col-sm-8 color-me-1 text-3" href="">INSURANCE POLICY</a>
                                <a class="col-sm-8 color-me-1 text-3" href="">IMPRESSUM</a>
                                <img class="fb" src="http://localhost/Home_DB/assets/images/faq/ic-facebook.png" alt="">
                                <img class="insta" src="http://localhost/Home_DB/assets/images/faq/ic-instagram.png" alt="">
                              </p>
                            </div>

                            <hr class="line2">
                        
                            <!-- Copyright -->
                            <div class="text-center copyright p-3">
                              © 2018 Helperhand:
                              <span> All rights reserved. <span>Terms and Conditions | Privacy Policy</span>   </span>
                            </div>
                            <!-- Copyright -->
                          </footer>
                          
                      
                        <!-- End of .container -->
              
<!-- /footer -->

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
      
      </body>
    </html>