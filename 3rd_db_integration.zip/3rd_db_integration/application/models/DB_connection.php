<?php

class DB_connection extends database{

    function contact($name, $mobile_number, $Email, $Subject, $Message, $file){


            if($this->Query("INSERT INTO ContactUs(Name, Mobile_number, Email, Subject, Message, file, time) VALUES ('$name', '$mobile_number', '$Email', '$Subject', '$Message', '$file', CURTIME())")){
            return true;
            
        }
        else{
     
            return false;
            
        }

        
        }

        function insertUser($data){

            if($this->Query("INSERT INTO User(First_name, Last_name, Mobile, Email, Password, token, status, typeId) VALUES 
                (?,?,?,?,?,?,?,?)", $data)){

                return true;
            }
            else{
                return false;
            }
        }

        function checkEmail($email){
            if ($this->Query("SELECT Email FROM User WHERE email = ?", [$email])) {
                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    return false;
                    
                }
                else{
                    return true;
                    
                }
            }
        }




        function userLogin($email, $password){
            if ($this->Query("SELECT * FROM User WHERE email = ?", [$email])) {
                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    $row = $this->fetch();
                    $dbPassword = $row->Password;
                    $userId = $row->Userid;
                    $First_name = $row->First_name;
                    $dbemail = $row->email;
                    $typeId = $row->typeId;
                    if (password_verify($password, $dbPassword)) {
                        // code...
                       
                        return ['status' => 'ok', 'data' => $userId, 'name' => $First_name, 'typeId' => $typeId];
                         if ($this->Query("SELECT * FROM Address WHERE Userid = '$userId'")) {
                   
                                $_SESSION['row']  = $this->fetchall();
                                 return($_SESSION['row']);
                                // return $data;
                                }
                    }
                    else{
                        return ['status' => 'passwordNotMatch'];
                    }
                }
                else{
                    return ['status' => 'emailNotFound'];
                }
            }
        }


        function Reset($new_pass ,$Email){
            if ($this->Query("UPDATE User SET Password=$new_pass WHERE email = ?", [$Email])) {
                // code...
                return true;
            }
            else{
                return false;
            }
        }






        function check_Email($Email){
            if ($this->Query("SELECT Email,First_name,token FROM User WHERE email = ?", [$Email])) {
                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    $row = $this->fetch();
                    $First_name = $row->First_name;
                    $token = $row->token;
                    return [ 'First_name' => $First_name, 'token' => $token];
                    return true;
                    // 
                    
                }
                else{
                    return false;
                    
                }
            }
        }


        public function check_availability($postalCode){
            if ($this->Query("SELECT * FROM user
                              JOIN useraddress on user.Userid = useraddress.Userid
                              JOIN city on useraddress.City = city.CityName
                              JOIN zipcode on zipcode.Cityid = city.CityId
                              WHERE user.Zipcode = ? 
                              AND User.typeId = 1", [$postalCode])) {
                                // code...
                if ($this->rowCount() > 0) {
                    // code...
                    if ($this->Query("SELECT Zipcode FROM user WHERE Zipcode = ?", [$postalCode])) {
                        // code...
                         $row = $this->fetch();
                        $postalCode = $row->Zipcode;
                        return ['postalCode' => $postalCode];
                    }
                   
                    return true;
                }
                else {
                    return false;
                }
            }
        }


        // public function plan($result){
        //     if ($this->Query("INSERT INTO form(date, time, first, cmt, sHrs, es) VALUES(?,?,?,?,?,?)", $result)) {
        //         // code...
        //         // echo "inserted";
        //         if ($this->Query("SELECT * FROM form")) {
        //             // code...
        //             $row = $this->fetch();
        //                 $date = $row->date;
        //                 return ['date' => $date];
        //         }
        //         return true;
        //     }
        //     else{
        //         // echo "not inserted";
        //         return false;
        //     }
        // }

        // public function in($First){
        //     if ($this->Query("INSERT INTO op(name) VALUES($first)")) {
        //         // code...
        //     }
        // }re

        public function Addaddress($street, $HN, $Pc, $city, $mobile, $Userid){
            // echo "hy";
            if ($this->Query("INSERT INTO Address(street, HN, Pc, city, mobile, Userid) VALUES('$street', '$HN', '$Pc', '$city', '$mobile' , $Userid)")) {
                // code...
                // if ($this->Query("SELECT * FROM Address WHERE Userid = '$Userid'")) {
                //     // code...
                //     // if ($this->rowCount() >) {
                //         // code...
                //     $_SESSION['row']  = $this->fetchall();
                //     // $_SESSION['street'] = $_SESSIONrow->street;
                //     // $_SESSION['HN'] = $row->HN;
                //     // $data = $this->fetchAll();
                //     // $_SESSION['res'] = array($row);
                //     // }
                //     // foreach ($_SESSION['res'] as $value) {
                //         // code...
                //         // echo $value;
                //      return($_SESSION['row']);
                //     // return $data;
                //     }
                //     // $res = mysqli_fetch_assoc($query);

                    // print_r($res);
                     // $row = $this->fetch();
                        // $street = $row->street;
                       return true;
                        // return ['street' => $street];
                    // return ['row' => $row];
                }
                
                else{
                return false;
            }
                // echo $street;
            }


            public function complete($userid, $hrs, $cmt, $has, $demo, $extra, $card, $helo, $postalCode, $date){
                if ($this->Query("INSERT INTO servicerequest(Userid, ServiceHours, comments, HasPets, ServiceHourlyRate, Extraservices, PaymentTransactionRefNo, Addid, Zipcode, ServiceStartDate) VALUES($userid, $hrs, '$cmt', $has, $demo, '$extra', $card, $helo, $postalCode, $date)")) {
                    // code...
                    return true;
                }
                else{
                    return false;
                }
            }
            
        }





// }
// }
// }



?>

