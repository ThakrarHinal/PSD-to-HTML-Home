<?php
class functions extends framework
{
     public function Home(){

           
            $this->view('Home');
    }

    public function Prices(){

               $this->view('Prices');
    }

    public function Contact(){

               $this->view('Contact');
    }

    public function FAQ(){

               $this->view('FAQ');
    }

    public function About(){

               $this->view('About');
    }

    public function signin(){

               $this->view('signin');
    }

    public function login(){

               $this->view('login');
    }

    public function Service_History(){

               $this->view('Service_History');
    }

    public function reset(){

               $this->view('reset');
    }

    public function Service_provider(){

               $this->view('Service_provider');
    }

    public function Upcoming_Service(){

               $this->view('Upcoming_Service');
    }

    public function demo(){

               $this->view('demo');
    }

    public function insert(){
        $this->view("Contact");
         
        if (isset($_POST['submit'])) {
            // code...

              $First_name = $this->input('First_name');
               $Last_name = $this->input('Last_name');
               $Mobile_number = $this->input('Mobile_number');
               $Email = $this->input('Email');
               $Subject = $this->input('Subject');
               $Message = $this->input('Message');
               $file = $this->input('file');
               $options = $this->input('options');

               $name = $First_name.$Last_name;
               $mobile_number = $options.$Mobile_number;

             $myModel = $this->model('DB_connection');
             if($myModel->contact($name, $mobile_number, $Email, $Subject, $Message, $file)){
                echo "added";
             }else{
                echo "not added";
             }
            
             require 'PHPMailerAutoload.php';
             require 'credentials.php';

            $mail = new PHPMailer;

            // $mail->SMTPDebug = 4;                               // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'hinalthakrar22@gmail.com';                 // SMTP username
            $mail->Password = 'ocdorpyqhctrnykd';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to 

            $mail->setFrom(EMAIL, 'Mailer');
            $mail->addAddress(EMAIL);     // Add a recipient
           
            $mail->addReplyTo(EMAIL);
            
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = 'Here is the subject';
            $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            if(!$mail->send()) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {
            echo 'Message has been sent';
            }

                }
                
                 

            }



            public function UserInsert(){
                $this->view('signin');

                if (isset($_POST['register'])) {
                    // code...

                    $userData = [
                    'First_name' => $this->input('First_name'),
                    'Last_name'  => $this->input('Last_name'),
                    'mobile'     => $this->input('mobile'),
                    'email'      => $this->input('email'),
                    'pass'       => $this->input('pass'),
                    'Repeat_password' => $this->input('Repeat_password'),
                    'emailError' => '',
                    'token'      => '',
                    'status'     => '',
                    'tupeId'     => '',
                  ];


                            $typeId = 1;
                            $status = "inactive";
                            $token = bin2hex(random_bytes(15));
                             $password = password_hash($userData['pass'], PASSWORD_DEFAULT) ;  

                  

                    $myModel = $this->model('DB_connection');
                        if($myModel->checkEmail($userData['email'])){
                            
                            if($userData['pass'] === $userData['Repeat_password']) {
                                // code...
                                $data = [$userData['First_name'], $userData['Last_name'], $userData['mobile'], $userData['email'], $password, $token, $status, $typeId];
                                 if($myModel->insertUser($data)){
                                    header("location:" . BASEURL . "/functions/Home");
                             }

                             }else{
                                $this->setFlash("passNotMatch", "password not matched");
                            }

                        }
                        else{

                            $this->setSession("exist", "already exist");
                            
                        }
                }

            }




            public function userlogin(){
                // $this->view('signin');
                setcookie('emailCookie', 'cookie set')? "pass": "fail";
                setcookie('passCookie', 'cookie set')? "pass": "fail";
                echo "hello";
                 if (isset($_POST['login'])) {
                    // code...
                    echo "hey there";
                    $userData = [
                    'email'      => $this->input('email'),
                    'password'   => $this->input('password'),
                    'remember-me' => $this->input('remember-me'),
                    'emailError' => '',
                 ];


                 $myModel = $this->model('DB_connection');
                 $result = $myModel->userLogin($userData['email'], $userData['password'], $userData['remember-me']);
                 if ($result['status'] === 'emailNotFound') {
                     // code...
                    echo "invalid Email";
                 }
                 elseif ($result['status'] === 'passwordNotMatch') {
                     // code...
                    echo "invalid password";
                 }
                 elseif ($result['status'] === 'ok'){
                    $this->setSession('Userid', $result['data']);
                    $this->setSession('First_name', $result['name']);
                    $this->setSession('typeId', $result['typeId']);
                    $Typid = $this->getSession('typeId');
                    if ($Typid == 0) {
                        // code...
                        header("location:" . BASEURL . "/functions/Service_History");
                    }
                    elseif($Typid == 1) {
                        header("location:" . BASEURL . "/functions/Upcoming_Service");
                    }
                    
                 }

            }

}

                public function logout(){
                    $this->destroy();
                    echo "hey";
                    header("location:" . BASEURL . "/functions/Home");
                }


                public function pass(){
                    $this->view('Home');
                    if (isset($_POST['send'])) {
                        // code...
                        $Email = $this->input('Email');
                         $myModel = $this->model('DB_connection');
                        $result = $myModel->check_Email($Email);
                         
                         if($result){

                             // $this->setSession('');
                             $this->setSession('First_name', $result['First_name']);
                             $this->setSession('token', $result['token']);
                            $res = $this->getSession('First_name');
                            $Token = $this->getSession('token');

                                require 'PHPMailerAutoload.php';
                                 require 'credentials.php';

                                $mail = new PHPMailer;

                                $mail->isSMTP();                                      // Set mailer to use SMTP
                                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                                $mail->Username = 'hinalthakrar22@gmail.com';                 // SMTP username
                                $mail->Password = 'ocdorpyqhctrnykd';                           // SMTP password
                                $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
                                $mail->Port = 587;                                    // TCP port to connect to 

                                $mail->setFrom(EMAIL, 'Mailer');
                                $mail->addAddress($Email);     // Add a recipient
                               
                                $mail->addReplyTo($Email);
                                
                                $mail->isHTML(true);                                  // Set email format to HTML

                                $mail->Subject = 'Forget password?';
                                $mail->Body    = 'This is '.$res.'  the HTML message body <b>in bold!</b> Message send! http://localhost/Home_DB/functions/reset?token='.$Token.'';
                                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                                if(!$mail->send()) {
                                    $this->setSession("email_sent", "email sent successfully");
                                   echo $this->getSession('email_sent');
                                } else {
                                     $this->setFlash("email_sent", "email sent successfully");
                                 }

                            }

                                 else{
                                    echo "not exist";
                                 }
                       
                        

                    }
                }
                public function forgetPass(){
                    if (isset($_POST['update'])) {
                        $this->view('reset');
                        $Email = $_POST['email'];
                            // if (isset($Token)) {
                                $new_pass = $this->input('new_pass');
                                $con_pass = $this->input('con_pass');
                                  $myModel = $this->model('DB_connection');
                                  if($myModel->Reset($new_pass, $Email)){
                                    $this->setSession("passUpdate", "password updated");
                                  }
                                  else{
                                    $this->setSession("passUpdateNot", "password not updated there is some error");
                                  }
                            }

                      
                    }

                    public function checkAvailability(){

                        header('Content-Type: application/json; charset=utf-8');
                        $data = ["status" => "Error", "Message" => "Please enter postal code"];
                        
                        session_start();
                        if(isset($_POST["PostalCode"])) {
                            $postalCode = $_POST['PostalCode'];
                            $data = file_get_contents('http://postalpincode.in/api/pincode/'.$postalCode);
                            $data = json_decode($data);
                            $_SESSION['postalCode'];

                            if (isset($data->PostOffice[0])) {
                                $myModel = $this->model('DB_connection');
                                if($myModel->check_availability($postalCode)){
                                     $this->setSession("postalCode", "$postalCode");
                                   // $pc = $_SESSION['postalCode'];
                                     $pc = $this->getSession("postalCode");
                                    $data = ["status" => "Success", "Message" => "matched", "pc" => $pc];
                                } else {
                                    $data = ["status" => "Error", "Message" => "not matched"];
                                }
                                // session_destroy();

                                // TODO: REMOVE THIS
                            //     if(true){
                            //         $data = ["status" => "Success", "Message" => "matched"];
                            //     } else {
                            //         $data = ["status" => "Error", "Message" => "not matched"];
                            //     }
                             }
                        }

                        echo json_encode($data);
                        // if (isset($_POST['check'])) {
                            // code...

                            //  $postalCode = $_POST['PostalCode'];
                            // $data = file_get_contents('http://postalpincode.in/api/pincode/'.$postalCode);
                            //  $data = file_get_contents('postalCode.json', false);
                            // $Data = json_decode($data);
                            // echo $postalCode;
                            // if (isset($Data->PostOffice[0])) {
                            //     // code...
                            //     $myModel = $this->model('DB_connection');
                            // if($myModel->check_availability($postalCode)){
                            //     echo "matched";
                            // }
                            // else {
                            //     echo "not matched";
                            // }
                            // }
                            // else{
                            //     // $this->view('demo');
                            //     $this->setFlash("postalCode", "invalid PostalCode");
                            //     echo "invalid PostalCode";
                            // }
                            
                        // }
                    }

                    public function schedule(){
                        header('Content-Type: application/json; charset=utf-8');
                         $data = ["status" => "Error", "Message" => "Please enter code"];
                        //  // echo $_POST['extras'];
                        // if (isset($_POST['continue'])) {
                        //     // code...
                        //     $formData = [
                        //         'date' => $this->input('date'),
                        //         'time' => $this->input('time'),
                        //         'hrs' => $this->input('hrs'),
                        //         'extras' => $this->input('extras'),
                        //         'cmt' => $this->input('cmt'),
                        //         'es' => 0,
                        //     ];

                            $es = 0.00;
                            $_SESSION['date'] = $_POST['date'];
                            $_SESSION['time'] = $_POST['time'];
                            $_SESSION['hrs'] = $_POST['hrs'];
                            // $extras = $_POST['extras'];
                            $_SESSION['cmt'] = $_POST['cmt'];
                            // $First = implode(",", $extras);

                            // $extras = $_POST['extras'];
                            // $First = implode(",", $extras);
                             $_SESSION['extras'] = $_POST['insert'];
                            // $First = implode(",", $extras);

                            // $_SESSION['Date'] = $date;
                            // $myModel = $this->model('DB_connection');
                            // $result = [$formData['date'], $formData['time'], $First, $formData['cmt'], $formData['hrs'], $es];
                            // $result = [$date, $time, $First, $cmt, $hrs, $es];
                            // if($myModel->plan($result)){
                                // $this->setSession("date", "$_SESSION['date']");
                            //       $data = ["status" => "Success", "Message" => "matched"];
                            //   }else{
                            //       $data = ["status" => "Error", "Message" => "not matched"];
                            //   }

                            if ($_POST['date']) {
                                // code...
                                $data = ["status" => "Success", "Message" => "matched", "date" => $_SESSION['date'], "ex" => $_SESSION['extras'], "data" => $_SESSION['row']];
                            }
                            else{
                                $data = ["status" => "Error", "Message" => "not matched"];
                            }

                             echo json_encode($data);
                        }


                        public function address(){
                            header('Content-Type: application/json; charset=utf-8');
                         $data = ["status" => "Error", "Message" => "Please enter code"];
                             // $this->view('demo');
                            if (isset($_POST["street"])) {
                                // code...
                                // $addData = [
                                    $street = $_POST['street'];
                                    $HN     = $_POST['HN'];
                                    $Pc     = $_POST['Pc'];
                                    $city   = $_POST['city'];
                                    $mobile = $_POST['mobile'];
                                    $Userid = $_POST['Userid'];
                                    // $Addid  = 14;
                        
                                $myModel = $this->model('DB_connection');

                                if($myModel->Addaddress($street, $HN, $Pc, $city, $mobile, $Userid)){
                                     // $this->setSession("data", "$data");
                                    // $this->setSession("row", "$row");
                                      // $res = $this->getSession("data");
                                      // $res = $this->getSession("row"); 
                                     // echo $res;  
                                      // $res1 = implode(",", $res);
                                    // print_r($data);
                                    // print_r($_SESSION['row']);
                                    $res;
                                    foreach ($_SESSION['row'] as  $values) {
                                        // code...
                                         $res = $values->street;
                                    }
                                      // echo $res1;
                                    $data = ["status" => "Success", "Message" => "matched", "data" => $_SESSION['row'], "res" => $res];
                                 // echo "true";
                                
                                }
                                else{
                                    // echo "false";
                                    $data = ["status" => "failer", "Message" => "not matched"];
                                }

                                echo json_encode($data);
                                
                            }
                        }

                        public function book(){
                            if (isset($_POST['card'])) {
                                // code...
                                // $bookData = [
                                //     'card' => $this->input('card'),
                                //     'PostalCode' => $this->input('PostalCode'),
                                // ];
                                $userid = $this->getSession('Userid');
                                $card = $_POST['card'];
                                $postalCode = $this->getSession('postalCode');
                                $date = $_SESSION['date'];
                                $time = $_SESSION['time'];
                                $serviceStart = $date.$time;
                                $hrs = $_SESSION['hrs'];
                                $cmt = $_SESSION['cmt'];
                                $helo = $_SESSION['Helo'];
                                $extra = $_SESSION['extras'];
                                $has = 1;
                                $demo = 100;


                                $myModel = $this->model('DB_connection');
                                // $res = [];
                                if($myModel->complete($userid, $hrs, $cmt, $has, $demo, $extra, $card, $helo, $postalCode, $date)){
                                    echo "done";
                                    // $pc = $this->getSession('date');
                                    // echo $pc;
                                    // echo ;
                                }
                                else{
                                    echo "not done";
                                    echo $date;
                                }


                            }
                        }

                        public function radio(){
                        header('Content-Type: application/json; charset=utf-8');
                         $data = ["status" => "Error", "Message" => "Please enter code"];
                            if (isset($_POST['helo'])) {
                                // code...
                                $_SESSION['Helo'] = $_POST['helo'];

                                $data = ["status" => "Success", "Message" => "matched", "helo" => $_SESSION['Helo']];
                            }
                            else{
                                 $data = ["status" => "failer", "Message" => "not matched"];
                            }

                            echo json_encode($data);
                        }

                       
                    // }
                // }

}

   

?>