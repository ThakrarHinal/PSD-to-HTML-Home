<?php 

define("HOST", "localhost");
define("USER", "root");
define("DATABASE", 'helperland_db');
define("PASSWORD", 'Hinal22@tc');

define('BASEURL', 'http://localhost/Home_DB');



?>