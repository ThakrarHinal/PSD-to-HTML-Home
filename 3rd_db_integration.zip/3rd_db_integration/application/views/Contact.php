<?php include('header.php');
 ?>

      <link rel="stylesheet" href="http://localhost/Home_DB/assets/css/Contact.css">
      <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script>

      <title>Contact</title>
 
        <div><img class="img-1 img-fluid" src="http://localhost/Home_DB/assets/images/contact/Bg-img.jpg" alt=""></div>

        <h2 class="text-center con comman"><b>Contact us</b> </h2>
            
        <div class="d-flex">
          <hr class="line">
          <img class="star" src="http://localhost/Home_DB/assets/images/contact/star.png" alt="">
          <hr class="line-1">
        </div>

        

        

      

      <div class="container">
          <div class="row">
            <div class="col-sm-4">
              <svg class="loc" xmlns="http://www.w3.org/2000/svg" width="34" height="54">
                  <path fill-rule="evenodd" fill="#1D7A8C" d="M17.1.2c4.584 0 8.85 1.713 12.7 4.9 3.06 3.8 4.194 7.252 4.194 12.53 0 4.203-3.059 9.95-5.726 14.975-.819 1.525-1.598 2.991-1.788 4.3L18.237 53.23c-.331.685-.357.978-1.831.645a1.378 1.378 0 0 1-.643-.645L7.952 36.905c-.623-1.309-1.403-2.775-2.202-4.3C3.63 27.581.5 21.833.5 17.63c0-5.278 1.413-8.74 4.491-12.53C8.7 1.913 12.316.2 17.1.2zm0 8.496c2.208 0 4.292.939 5.791 2.444 1.5 1.505 2.435 3.598 2.435 6.49 0 1.74-.935 3.831-2.435 5.337-1.499 1.505-3.583 2.444-5.791 2.444-2.389 0-4.473-.939-5.992-2.444-1.499-1.505-2.435-3.597-2.435-5.337 0-2.894.936-4.985 2.435-6.49 1.519-1.505 3.603-2.444 5.992-2.444zm3.844 5.264c-1.013-1.16-2.395-2.506-3.844-2.506-1.649 0-2.42 1.346-3.54 2.506-1.13.152-2.14 1.54-2.14 3.68 0 .968 1.01 2.357 2.14 3.48 1.12 1.17 1.891 1.534 3.54 1.534 1.449 0 2.831-.364 3.844-1.534 1.012-1.123 1.636-2.512 1.636-3.48.001-2.14-.622-3.528-1.636-3.68zM27.8 6.957c-3.311-2.6-6.856-4.203-10.7-4.203-3.35 0-7.59 1.603-10.161 4.203-2.59 2.58-4.188 6.159-4.188 10.683 0 3.529 2.883 8.925 5.414 13.675.819 1.545 1.598 3.03 2.26 4.398L17.8 49.456l5.772-13.743c.663-1.368 1.568-2.853 2.26-4.398 2.531-4.75 5.414-10.146 5.414-13.675.002-4.524-1.595-8.103-3.446-10.683z"/>
              </svg>
              <p class="loc-txt txt">1111 Lorem ipsum text 100, Lorem ipsum AB</p>
            </div>
            <div class="col-sm-4">
              <svg class="phone" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="46" height="52">
                  <image width="46" height="52" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAA0CAMAAADCKvr4AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAACWFBMVEUdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeowdeoz///+TM67+AAAAxnRSTlMAAgYImPdcH8uuYcJZNOX0mQTXDGTaIKIDR078zyEl+o/cG7XsD3JB+BUsB7P5pvYBgRprXwtN8Mqw8iNTMCIqdRKvu/EOEPWfkP08Y7ge0hRdUU/+aR2cxwV/0N6tSDPjhOfilifmKKRAHBmpqyaSUBPv1ttbZSnOFo77t1UK8+oN7dmDnXhLQmZ8glK+0zasVGLJbVeJzemHL8SnCUPdfj6jMoy0F2juWIo5pTpMVnrfRugtky6huuEYXtV9cOCGsqiIbjtmgvnvAAAAAWJLR0THjQVKWwAAAAd0SU1FB+ULEgsMOxZ2x10AAALXSURBVEjHlZVnVxNREIYnhtCCFBWIhmIQkGJwQSIlQECDFFFAgwULoAKCqBAQpAnYsYANURDFgijYsff6/i43myyScza763yZJ5Mnc+7cvblLZA/FPPqPULqpAHe5tocnvLzV8JFnz/f1gz8FLPBdKMdehMCgYJWGFmOJDNtbGxJKYeFLiXQ6aTsCy2w74xkZRdFYLqkHx8TaUhw7aLxqhaSuT+BSQMhKhhKRJKVjlT0ns4OG+iVI2AasdlBKKlFaukR7IzIcFI1MykKiuG4Kz3ZQDtYoNGvNuaL6urx8HgsKlbQeReLtzRsCHLRRxf6y2Fdcd1PxxKhTSqgUm0T1zeyEfHtLGSlRIKpvyds6236bfns8ysVXs2OnkscMJO8KjxPXd6NilitRWKUR13P2pPLosZc/EiKxT1Vth1zU1EraNE+73w6lqJO2SeEPIwfeqJeh0wE0cDlJf5CR41cVHuLyYTTK0ZuszfZbrEUVIMc/glYut+GonNtPoda3c+CODjntazu77FPmo1uOn+1YzrHiTpOc5YT0ZHFQn94b8a/q0u87XmP/0qQ9wcsnT532cOWfgRcPzQZbPotCIL3flX8O57nMXMBFAymKegYGKUeHLqUL/xIu2+EKrl5zgzlmiOXrenOmsG4Y5v8prTcsuDkyiltjRLfvYFz42bWnWB0HvmmQXf7YOCrvsptwD6Ntgn6TNS927uf7ndoH7H4NwVom6Gf2+BmdChMIKSF6OIwJQb86ptd5sslHeEykmYJWcOIwi3XauaDGkyZintbgmZBfH4jnTgXmBV6+Yk9Ty0yOkJ80ivJ4p8pra+cb2/X4VnD9ynd4H+RU0TTgQ1Q3Pgo/L5q0zHxyrvjMwDrAuNBp5DPUfU4D9FsiK8hlGL7EIHFOt6/4ZiSRYIwJwHfHizDqB372kUQEpQHFU43TjR06/JKSuR35XQw2VLo6Ro7OTWH6U83zXyXRw9syqx3QAAAAAElFTkSuQmCC"/>
              </svg>
              <div class="ph-txt txt">+49 (40) 123 56 7890</div>
              <div class=" txt">+49 (40) 987 56 0000</div>
            </div>
            <div class="col-sm-4">
              <img class="mail" src="http://localhost/Home_DB/assets/images/contact/E-mail.png" alt="">
              <div class="mail-txt txt">info@helperland.com</div>
            </div>
          </div>
        </div>

        <hr class="hr">
        
        <h2 class="text-center txt txt-hed touch comman"><b>Get in touch with us</b> </h2>

             
      <div class="toast align-items-center justify-content-center" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body" id="message"></div>
          <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
      </div>
        <div class="container">
          <div class="row justify-content-center margin-top-50">
              <div class="col-md-6">
                
                  <form method="post" action="<?php echo BASEURL; ?>/functions/insert" id="contact" class="row g-3">
                   
                      <div class="col-md-6">
                          <input type="text" name="First_name" class="form-control" id="inputEmail4" placeholder="First Name">
                      </div>
                      <div class="col-md-6">
                          <input type="text" name="Last_name" class="form-control" placeholder="Last Name">
                      </div>
                      <div class="col-2">
                          <select  class="input-group-text" name="options" id="">
                            <option value="">+41</option>
                            <option value="">+91</option>
                          </select>


                      </div>
                      <div class="col-4">
                          <input type="text" name="Mobile_number" class="form-control" placeholder="Mobile Number">
                      </div>
                      <div class="col-6">
                          <input type="email" name="Email" id="email" class="form-control" placeholder="Email">
                      </div>
                      <div class="col-md-12">
                        <select class="form-control" name="Subject" id="">
                          <option value="">Subject</option>
                        </select>
                      </div>
                      <div class="col-12">
                          <textarea rows="4" name="Message" cols="50" class="form-control" aria-placeholder="Message" placeholder="Message">
                        </textarea>
                      </div>
                      <div class="col-6">
                          <label>Attach File</label>
                          <input type="file" name="file" class="form-control" >
                      </div>
                      <div class="col-12 text-center">
                          <button type="submit" name="submit" id="submit" value="CREATE" class="btn submit1">Submit</button>
                      </div>

                  </form>
              </div>
          </div>
      </div>
        <div class="present"><img class=" img-fluid image1" src="http://localhost/Home_DB/assets/images/contact/Map.jpg" alt="">
          <svg class="loc-2 image2" xmlns="http://www.w3.org/2000/svg" width="48" height="67">
              <path fill-rule="evenodd" fill="#FF6060" d="M45.959 16.672c-.238-.894-.722-1.846-1.08-2.68C40.598 3.688 31.242.5 23.688.5 13.575.5 2.437 6.785.95 20.782v2.859c0 .119.041 1.191.54 1.728.393 7.021 5.649 13.759 10.16 20.429 3.638 7.147 8.02 14.177 12.48 21.502 2.559-4.883 5.227-9.529 7.843-13.996.713-1.311 1.541-2.621 2.255-3.873.475-.833 1.384-1.666 2.052-2.441 3.971-7.743 11.2-15.546 11.2-23.23v-3.156c0-.834-1.3-3.752-1.521-3.932zM23.873 31.27c-2.973 0-6.226-1.731-7.473-5.842-.599-.654-.58-1.966-.58-2.086v-1.846c0-5.24 4.444-7.623 8.309-7.623 4.759 0 8.439 3.812 8.439 8.578 0 4.765-3.937 8.819-8.695 8.819z"/>
          </svg>
      </div>



      <div class="text-center news"><b>GET OUR NEWSLETTER</b>
          
        </div><br>

          
        <form class="row justify-content-lg-center">
          
          <div class="col-sm-2">
            <input type="text" class="form-control email" id="inputEmail" placeholder="YOUR EMAIL">
          </div>
          <div class="col-sm-2">
            <button type="submit" class="btn Submit  mb-3">Submit</button>
          </div>
          
        </div>
        
        </form>

        
      
        <div class=" my-5">

          <footer class=" text-center text-white" style="background-color: #111111;">
          <!-- Grid container -->
          <div class="container p-3 pb-0">
            <!-- Section: Social media -->
            <section class="mb-4">
              <a href="<?php echo BASEURL; ?>/functions/Home" class="foot-link"><span class="foot"> <img src="http://localhost/Home_DB/assets/images/About/footer.png" alt=""></span></a>
              <a href="<?php echo BASEURL; ?>/functions/Home" class="foot-link"><span class="foot1">HOME</span></a>
              <a href="<?php echo BASEURL; ?>/functions/About" class="foot-link"><span class="foot1">ABOUT</span></a>
              <a href="#" class="foot-link"><span class="foot1" >TESTIMONIALS</span></a>
              <a href="<?php echo BASEURL; ?>/functions/FAQ" class="foot-link"><span class="foot1">FAQS</span></a>
              <a href="#" class="foot-link"><span class="foot1">INSURANCE POLICY</span></a>
              <a href="#" class="foot-link"><span class="foot1">IMPRESSUM</span></a>  
              <span class="fb"> <img src="http://localhost/Home_DB/assets/images/About/FB.png" alt=""></span>
              <span> <img src="http://localhost/Home_DB/assets/images/About/insta (1).png" alt=""></span>
              
              
        
            
            </section>
            <!-- Section: Social media -->
          </div>

          <hr class="hr1">
          <!-- Grid container -->
        
          <!-- Copyright -->
          <div class="text-center p-3 l-txt" style="background-color: #111111;">
            © 2020 Copyright:
            <a class="text-white l-txt">All rights reserved. Terms and Conditions | Privacy Policy</a>
          </div>
          <!-- Copyright -->
        </footer>
          
        </div>



        <script src="http://localhost/Home_DB/public/assets/js/validation.js"></script>
        
        
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
      
  </body>
  </html>