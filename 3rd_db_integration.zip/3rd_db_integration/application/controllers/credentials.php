<?php

define('EMAIL', 'hinalthakrar22@gmail.com');
define('PASS', 'Chandulal55@');


?>