<?php
session_start();
include "../config/config.php";
include "../system/init.php";

?>

