


    <h2 class="text-center news" ><b> GET OUR NEWSLETTER</b>
        
        </h2><br>

          
        <form class="row g-2 container-fluid justify-content-center">
          
          <div class="col-auto ">
            <input type="text" class="form-control email" id="inputEmail" placeholder="YOUR EMAIL">
          </div>
          <div class="col-auto">
            <button type="submit" class="btn Submit  mb-3">Submit</button>
          </div>
          
        </div>
        
        </form>

        <div class=" my-5">

          <footer class=" text-center text-white" style="background-color: #111111;">
          <!-- Grid container -->
          <div class="container p-3 pb-0">
            <!-- Section: Social media -->
            <section class="mb-4">
              <span class="foot"> <img src="http://localhost/Home_DB/assets/images/About/footer.png" alt=""></span>
              <span class="foot1">HOME</span>
              <span class="foot1">ABOUT</span>
              <span class="foot1">TESTIMONIALS</span>
              <span class="foot1">FAQS</span>
              <span class="foot1">INSURANCE POLICY</span>
              <span class="foot1">IMPRESSUM</span>
              <span class="fb"> <img src="http://localhost/Home_DB/assets/images/About/FB.png" alt=""></span>
              <span> <img src="http://localhost/Home_DB/assets/images/About/insta (1).png" alt=""></span>
              
              
        
            
            </section>
            <!-- Section: Social media -->
          </div>

          <hr class="hr1">
          <!-- Grid container -->
        
          <!-- Copyright -->
          <div class="text-center p-3 l-txt" style="background-color: #111111;">
            © 2020 Copyright:
            <a class="text-white l-txt">All rights reserved. Terms and Conditions | Privacy Policy</a>
          </div>
          <!-- Copyright -->
        </footer>
          
        </div>

      
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    
    </body>
  </html>