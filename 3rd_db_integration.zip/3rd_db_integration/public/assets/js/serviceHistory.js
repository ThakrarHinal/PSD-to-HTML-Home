function responsive_menu(){
    var e = document.getElementById('menu_small');
    if(e.className === 'list1'){
        e.className += 'responsive';
    }
    else{
        e.className = 'list1';
    }
}


// function responsive_menu(){
//     var e = document.getElementById('menu_small');
//     if(e.className === 'list1'){
//         e.className += 'responsive';
//     }
//     else{
//         e.className = 'list1';
//     }
// }
// function get_details(){
//     var PostalCode = $('#PostalCode').val();
//     if (PostalCode == '') {
//         alert("hello");
//     }
//     else{
//         jQuery.ajax({
//             url: 'set_up.php',
//             type: 'post',
//             data: 'pincode='+pincode,
//             success: function(data){
//                 console.log(data);
//             }
//         })
//     }
// }